# Operating Systems Final Project

Compilation: run make in directory, creates pj-final
Run: ./pj-final graph all/out