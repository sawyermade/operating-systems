# OS Project 2: Shared Memory & Semaphores

## Compilation
$ gcc danielsawyer-pj2.c

creates binary named a.out

## Run
$ ./a.out
