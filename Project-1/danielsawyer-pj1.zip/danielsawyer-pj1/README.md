# os-pj1
To Compile and Run:

1. gcc pj1.c

2. ./a.out
